import onlineUsersReducer from './onlineUsersSlice/onlineUsersSlice';

export const rootReducer = {
  onlineUsers: onlineUsersReducer,
};
