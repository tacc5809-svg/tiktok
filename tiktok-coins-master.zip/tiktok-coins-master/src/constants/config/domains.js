export const schema = 'https';
export const baseDomain = 'tiktokcoin.ru';
export const baseApi = `${schema}://api.${baseDomain}/v1`;
