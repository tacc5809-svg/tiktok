export const TIKTOK_LINK = 'https://www.tiktok.com/foryou?lang=ru-Ru';
