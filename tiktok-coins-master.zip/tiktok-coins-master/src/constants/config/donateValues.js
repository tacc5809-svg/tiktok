export const donateValues = [
  {
    value: 150,
  },
  {
    value: 199,
  },
  {
    value: 279,
  },
  {
    value: 299,
  },
  {
    value: 349,
  },
  {
    value: 499,
  },
  {
    value: 799,
  },
  {
    value: 999,
  },
];

export const MIN_DONATE_VALUE = 500;
export const MAX_DONATE_VALUE = 5000;
