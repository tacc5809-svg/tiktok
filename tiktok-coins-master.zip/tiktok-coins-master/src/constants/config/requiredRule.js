export const requiredRule = {
  required: true,
  message: 'Это обязательное поле!',
};
