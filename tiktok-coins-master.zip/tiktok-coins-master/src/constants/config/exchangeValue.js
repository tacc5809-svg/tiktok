export const EXCHANGE_VALUE = '10 TikCoin = 1₽';

export const EXCHANGE_CROWNS_VALUE = '1₽ = 1';
