import { Button } from 'components/common/Button/Button';
import styled from 'styled-components';

export const Btn = styled(Button)`
  width: 100%;
`;
