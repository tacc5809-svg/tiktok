import React from 'react';

export const AutoclickerCard = () => {
  return <div></div>;
};
