import { InputNumber } from 'antd';
import styled from 'styled-components';

export const NumberInput = styled(InputNumber)`
  width: 100%;
`;
