import styled from 'styled-components';
import { Button } from 'components/common/Button/Button';

export const SubmitBtn = styled(Button)`
  width: 100%;
`;
