import React from 'react';
import * as S from './ModalTitle.styles';

export const ModalTitle = ({ children }) => <S.Title>{children}</S.Title>;
