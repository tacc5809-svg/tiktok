import React from 'react';
import * as S from './Title.styles';

export const Title = ({ children }) => <S.Title>{children}</S.Title>;
