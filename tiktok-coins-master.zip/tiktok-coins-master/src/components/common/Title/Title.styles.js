import styled from 'styled-components';
import { Typography } from 'antd';

export const Title = styled(Typography.Title)``;
