export const useTop = () => {
  const top = [
    {
      name: 'Алла Казарцева',
      tiktoks_watched: 123,
      image_url: null,
    },
    {
      name: 'Алла Казарцева',
      tiktoks_watched: 123,
      img: null,
    },
    {
      name: 'Алла Казарцева',
      tiktoks_watched: 123,
      img: null,
    },
    {
      name: 'Алла Казарцева',
      tiktoks_watched: 123,
      img: null,
    },
    {
      name: 'Алла Казарцева',
      tiktoks_watched: 123,
      img: null,
    },
    {
      name: 'Алла Казарцева',
      tiktoks_watched: 123,
      img: null,
    },
    {
      name: 'Алла Казарцева',
      tiktoks_watched: 123,
      img: null,
    },
    {
      name: 'Алла Казарцева',
      tiktoks_watched: 123,
      img: null,
    },
    {
      name: 'Алла Казарцева',
      tiktoks_watched: 123,
      img: null,
    },
    {
      name: 'Алла Казарцева',
      tiktoks_watched: 123,
      img: null,
    },
  ];

  return top;
};
