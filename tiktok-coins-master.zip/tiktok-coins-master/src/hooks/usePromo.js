export const usePromo = () => {
  const promo = {
    isValid: true,
    award: 50,
    currency: 'TikCoin',
  };

  return promo;
};
