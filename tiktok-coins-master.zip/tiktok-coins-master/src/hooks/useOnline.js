export const useOnline = () => {
  const online = {
    onlineAmount: 2000,
  };

  return online;
};
