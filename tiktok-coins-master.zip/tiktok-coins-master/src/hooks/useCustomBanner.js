export const useCustomBanner = () => {
  const customCard = {
    title: 'Кастомный баннер',
    description: 'Описание',
    btnText: 'Текст 123',
    end_date: 1637784000,
  };

  return customCard;
};
